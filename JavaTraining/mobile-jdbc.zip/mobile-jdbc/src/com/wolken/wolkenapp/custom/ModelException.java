package com.wolken.wolkenapp.custom;

public class ModelException extends Exception {
	
	@Override
	public String toString() {
		
		return "Invalid entry - Model Name must be more than 3 characters";
	}
	

}
