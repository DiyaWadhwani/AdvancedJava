package com.wolken.wolkenapp.service;

import com.wolken.wolkenapp.custom.EmailException;
import com.wolken.wolkenapp.custom.NameException;
import com.wolken.wolkenapp.custom.PhoneNumException;
import com.wolken.wolkenapp.custom.RequiredException;
import com.wolken.wolkenapp.dao.EnquiryDAO;
import com.wolken.wolkenapp.dao.EnquiryDAOImpl;
import com.wolken.wolkenapp.dto.EnquiryDTO;

public class EnquiryServiceImpl implements EnquiryService {

	public void validateAndUpdate(EnquiryDTO enquiryDTO) {
		
		EnquiryDAO enquiryDAO = new EnquiryDAOImpl();
		String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";

		try {
			if(enquiryDTO.getFirstName().length() == 0 || enquiryDTO.getLastName().length() == 0 || enquiryDTO.getDob().length() == 0 || enquiryDTO.getEmail().length() == 0 || enquiryDTO.getQual().length() == 0) {
				throw new RequiredException();
			}
			
			
			if (enquiryDTO.getFirstName().length() < 3 ) {
				throw new NameException();
			}
			
			

			if (enquiryDTO.getLastName().length() < 1) {
				throw new NameException();
			}
			
			if (enquiryDTO.getPhnum() < 0) {
				throw new PhoneNumException();
			}
		
			if (! enquiryDTO.getEmail().matches(regex)) {
				throw new EmailException();
			}
		}
		
		catch (NameException | PhoneNumException | EmailException | RequiredException e) {
			System.out.println(e.toString());
			return;
		}
		
		int rows = enquiryDAO.add(enquiryDTO);

		if (rows > 0) {
			System.out.println("Added !!\n" + rows + " row(s) affected");
		} else {
			System.out.println("Cannot add !! Error exists");
		}
	}

}
