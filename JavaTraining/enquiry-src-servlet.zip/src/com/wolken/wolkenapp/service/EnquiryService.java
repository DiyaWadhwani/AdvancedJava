package com.wolken.wolkenapp.service;

import com.wolken.wolkenapp.dto.EnquiryDTO;

public interface EnquiryService {
	
	public void validateAndUpdate(EnquiryDTO enquiryDTO);

}
