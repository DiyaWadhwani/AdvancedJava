package com.wolken.wolkenapp.dao;

import java.sql.*;

import com.wolken.wolkenapp.dto.EnquiryDTO;

public class EnquiryDAOImpl implements EnquiryDAO {

	public int add(EnquiryDTO enquiryDTO) {

		int rows = 0;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try (Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");) {

			try (PreparedStatement ps = con.prepareStatement("INSERT INTO enquiry_details VALUES (?,?,?,?,?,?,?)");) {

				ps.setString(1, enquiryDTO.getFirstName());
				ps.setString(2, enquiryDTO.getLastName());
				ps.setString(3, enquiryDTO.getGender());
				ps.setString(4, enquiryDTO.getDob());
				ps.setLong(5, enquiryDTO.getPhnum());
				ps.setString(6, enquiryDTO.getEmail());
				ps.setString(7, enquiryDTO.getQual());
				
				rows = ps.executeUpdate();
				
				ps.close();
			}
			con.close();
		}
		catch (SQLException e) {
			System.out.println(e.toString());
		}

		return rows;
	}

}
