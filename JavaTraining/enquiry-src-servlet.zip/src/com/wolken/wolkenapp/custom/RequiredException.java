package com.wolken.wolkenapp.custom;

public class RequiredException extends Exception {
	
	@Override
	public String toString() {
		return "Please enter all fields before clicking on the Submit botton";
	}
}
