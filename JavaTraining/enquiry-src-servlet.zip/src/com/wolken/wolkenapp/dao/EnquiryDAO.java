package com.wolken.wolkenapp.dao;

import com.wolken.wolkenapp.dto.EnquiryDTO;

public interface EnquiryDAO {
	
	public int add (EnquiryDTO enquiryDTO);

}
