package com.wolken.wolkenapp.service;

import com.wolken.wolkenapp.dto.BiscuitsDTO;

public interface BiscuitsService {

	public boolean validateAndService(BiscuitsDTO biscuitsDTO);
}
