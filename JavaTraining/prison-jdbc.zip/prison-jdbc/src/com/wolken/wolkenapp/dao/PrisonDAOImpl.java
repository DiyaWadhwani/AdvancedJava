package com.wolken.wolkenapp.dao;

import java.sql.*;

import com.wolken.wolkenapp.dto.PrisonDTO;

public class PrisonDAOImpl implements PrisonDAO {

	@Override
	public int insert(PrisonDTO prisonDTO) throws SQLException {

		int rows = 0;

		try (Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");)
		{
			try (PreparedStatement ps = con.prepareStatement("INSERT into prison_details VALUES (?,?,?,?)");)
			{
				ps.setInt(1, prisonDTO.getPrisonID());
				ps.setString(2, prisonDTO.getPrisonName());
				ps.setInt(3, prisonDTO.getPrisonInmates());
				ps.setInt(4, prisonDTO.getPrisonStaff());

				rows = ps.executeUpdate();
				
				ps.close();
			}
			con.close();
		}
		return rows;
	}

	@Override
	public int updateNameByID(String prisonName, int prisonID) throws SQLException {

		int rows = 0;

		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");)
		{

			try (PreparedStatement ps = con.prepareStatement("UPDATE prison_details SET prison_name = ? where prison_id= ?");)
			{
				
				ps.setString(1, prisonName);
				ps.setInt(2, prisonID);

				rows = ps.executeUpdate();
				
				ps.close();
			}
			con.close();
		}		
		return rows;
	}

	@Override
	public void displayPrisoners(PrisonDTO prisonDTO) {

		System.out.println("\nPrison ID : " + prisonDTO.getPrisonID() + "\nPrison Name : " + prisonDTO.getPrisonName()
				+ "\nNo. of Inmates : " + prisonDTO.getPrisonInmates() + "\nStaff Capacity : "
				+ prisonDTO.getPrisonStaff());
	}

	@Override
	public int displayAll() throws SQLException {

		int results = 0;
		PrisonDTO prisonDTO = new PrisonDTO();

		try (Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");)
		{
//			System.out.println(con);
			try( PreparedStatement ps = con.prepareStatement("SELECT * FROM prison_details");)
			{
				try (ResultSet rs = ps.executeQuery();)
				{
					while (rs.next()) {
						results++;
						prisonDTO.setPrisonID(rs.getInt(1));
						prisonDTO.setPrisonName(rs.getString(2));
						prisonDTO.setPrisonInmates(rs.getInt(3));
						prisonDTO.setPrisonStaff(rs.getInt(4));

						displayPrisoners(prisonDTO);
				}
			}
			ps.close();
		}
		con.close();
	}
		return results;
	}

	public int deleteEntryByID(int prisonID) throws SQLException {

		int rows = 0;

		try (Connection con = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");)
		{
			try (PreparedStatement ps = con.prepareStatement("DELETE FROM prison_details WHERE prison_id = ?");)
			{
				ps.setInt(1, prisonID);

				rows = ps.executeUpdate();
				
				ps.close();
			}
			con.close();
		}
		return rows;
	}

	@Override
	public int deleteAll() throws SQLException {

		int done = 1;

		try (Connection con = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");)
		{
//			System.out.println(con);
			try (PreparedStatement ps = con.prepareStatement("TRUNCATE TABLE prison_details");)
			{
				done = ps.executeUpdate();
				
				ps.close();
			}
		}

//		catch (SQLException e) {
//
//			e.toString();
//		}
		return done;
	}

}
