package com.wolken.wolkenapp.service;

import java.sql.SQLException;

import com.wolken.wolkenapp.custom.InvalidID;
import com.wolken.wolkenapp.custom.InvalidInmates;
import com.wolken.wolkenapp.custom.InvalidStaff;
import com.wolken.wolkenapp.dao.PrisonDAO;
import com.wolken.wolkenapp.dao.PrisonDAOImpl;
import com.wolken.wolkenapp.dto.PrisonDTO;

public class PrisonServiceImpl implements PrisonService {

	PrisonDAO prisonDAO = new PrisonDAOImpl();

	@Override
	public void validateAndInsert(PrisonDTO prisonDTO) throws SQLException {

//		int exception[] = {0,0,0};

		try {
			if (prisonDTO.getPrisonID() < 0) {
				throw new InvalidID();
			}
		} catch (InvalidID e) {
			System.out.println("Item not added in database\nSome error exists !!");
			System.out.println(e);
			return;
		}

		try {
			if (prisonDTO.getPrisonInmates() < 20) {
				throw new InvalidInmates();
			}
		}

		catch (InvalidInmates e) {
			System.out.println("Item not added in database\nSome error exists !!");
			System.out.println(e.toString());
			return;
		}

		try {
			if (prisonDTO.getPrisonStaff() < 45) {
				throw new InvalidStaff();
			}
		}

		catch (InvalidStaff e) {
			System.out.println("Item not added in database\nSome error exists !!");
			System.out.println(e.toString());
			return;
		}

		int rows = prisonDAO.insert(prisonDTO);
		// throw 2 exceptions :
		// 1.duplicate element
		if (rows > 0) {
			System.out.println("\n" + rows + " row(s) affected !!\nItem added in database : ");
			prisonDAO.displayPrisoners(prisonDTO);
		}
	}

	@Override
	public void validateAndUpdate(String prisonName, int prisonID) throws SQLException {

		if (prisonName.length() <= 0 || prisonName.length() < 2) {
			System.out.println("Item not added in database\nSome error exists !!");
		} else if (prisonID < 0) {
			System.out.println("Item not added in database\nSome error exists !!");
		} else {
			int rows = prisonDAO.updateNameByID(prisonName, prisonID);
			if (rows > 0) {
				System.out.println("Prison Name updated\n" + rows + " row(s) affected !!");
			} else {
				System.out.println("Update failed !!\nSome error has occured !!");
			}
		}
	}

	@Override
	public void validateAndDelete(int prisonID) throws SQLException {

		if (prisonID < 0) {
			System.out.println("Item not added in database\nSome error exists !!");
		} else {
			int rows = prisonDAO.deleteEntryByID(prisonID);
			if (rows > 0) {
				System.out.println("Entry with ID " + prisonID + " deleted\n" + rows + " row(s) affected !!");
			} else {
				System.out.println("Could not perform Delete operation\nSome error has occured !!");
			}
		}
	}
}
