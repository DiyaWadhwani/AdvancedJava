package com.wolken.wolkenapp.enquiry;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import com.wolken.wolkenapp.custom.RequiredException;
import com.wolken.wolkenapp.dto.EnquiryDTO;
import com.wolken.wolkenapp.service.EnquiryService;
import com.wolken.wolkenapp.service.EnquiryServiceImpl;

@WebServlet("/enquiry")
public class EnquiryServlet extends HttpServlet {
	
	EnquiryDTO enquiryDTO = new EnquiryDTO();
	
	@Override
	public void service(ServletRequest req, ServletResponse resp) throws ServletException, IOException {
		
		enquiryDTO.setFirstName(req.getParameter("fname"));
		enquiryDTO.setLastName(req.getParameter("lname"));
		enquiryDTO.setGender(req.getParameter("gender"));
		enquiryDTO.setDob(req.getParameter("dob"));
		String num = req.getParameter("phnum");
		try {
			if(num.length() == 0) {
				throw new RequiredException();
			}
		}
		catch(RequiredException e) {
			System.out.println(e.toString());
		}
		enquiryDTO.setPhnum(Long.parseLong(num));
		enquiryDTO.setEmail(req.getParameter("email"));
		enquiryDTO.setQual(req.getParameter("qual"));
		
		EnquiryService enquiryService = new EnquiryServiceImpl();
		enquiryService.validateAndUpdate(enquiryDTO);
		
		PrintWriter printWriter = resp.getWriter();
//		if(req.getParameter("dob").)
		printWriter.write("Thankyou for your response\nWe will get back to you shortly !!");
	}
	

}
