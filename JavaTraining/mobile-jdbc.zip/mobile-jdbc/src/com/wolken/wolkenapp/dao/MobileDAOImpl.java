package com.wolken.wolkenapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

//import java.sql.*;

import com.wolken.wolkenapp.dto.MobileDTO;

public class MobileDAOImpl implements MobileDAO {

	MobileDTO mobileDTO = new MobileDTO();
	int rows = 0;
	int result = 0;

	public int add(MobileDTO mobileDTO) {

		try (Connection con = DriverManager
				.getConnection("****");) {
//						+ "jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01"
						

			try (PreparedStatement ps = con.prepareStatement("INSERT INTO mobile_details VALUES (?,?,?,?,?)");) {

				ps.setString(1, mobileDTO.getMobSerialNum());
				ps.setString(2, mobileDTO.getMobBrand());
				ps.setString(3, mobileDTO.getMobModel());
				ps.setDouble(4, mobileDTO.getMobPrice());
				ps.setInt(5, mobileDTO.getMobStock());

				rows = ps.executeUpdate();

				ps.close();
			}

			con.close();
		}

		catch (SQLException e) {
			System.out.println(e.toString());
		}

		return rows;
	}

	public int updatePriceBySerialNum(String mobSerialNum, double mobPrice) {

		try (Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");) {
			try (PreparedStatement ps = con
					.prepareStatement("UPDATE mobile_details SET mobPrice = ? WHERE mobSerialNum = ?");) {

				ps.setDouble(1, mobPrice);
				ps.setString(2, mobSerialNum);

				rows = ps.executeUpdate();

				ps.close();
			}

			con.close();
		}

		catch (SQLException e) {
			System.out.println(e.toString());
		}

		return rows;

	}

	public int updateStockByModel(String mobModel, int mobStock) {

		try (Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");) {
			try (PreparedStatement ps = con
					.prepareStatement("UPDATE mobile_details SET mobStock = ? where mobModel = ?");) {
				ps.setInt(1, mobStock);
				ps.setString(2, mobModel);

				rows = ps.executeUpdate();

				ps.close();
			}

			con.close();
		}

		catch (SQLException e) {
			System.out.println(e.toString());
		}

		return rows;
	}

	public int displayByBrand(String mobBrand) {

		try (Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");) {
			try (PreparedStatement ps = con.prepareStatement("SELECT * FROM mobile_details WHERE mobBrand = ?");) {
				ps.setString(1, mobBrand);

				try (ResultSet rs = ps.executeQuery()) {
					
					result = 0;

					while (rs.next()) {

						result++;

						mobileDTO.setMobSerialNum(rs.getString("mobSerialNum"));
						mobileDTO.setMobBrand(rs.getString("mobBrand"));
						mobileDTO.setMobModel(rs.getString("mobModel"));
						mobileDTO.setMobPrice(rs.getDouble("mobPrice"));
						mobileDTO.setMobStock(rs.getInt("mobStock"));

						System.out.println("\nDatabase Entry " + result);
						displayMobile(mobileDTO);

					}
				}
				ps.close();
			}
			con.close();
		}

		catch (SQLException e) {
			System.out.println(e.toString());
		}

		return result;

	}

	public int displayBySerialNum(String mobSerialNum) {

		try (Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");) {
			try (PreparedStatement ps = con.prepareStatement("SELECT * FROM mobile_details WHERE mobSerialNum = ?");) {
				ps.setString(1, mobSerialNum);

				try (ResultSet rs = ps.executeQuery()) {
					
					result = 0;

					while (rs.next()) {

						result++;

						mobileDTO.setMobSerialNum(rs.getString("mobSerialNum"));
						mobileDTO.setMobBrand(rs.getString("mobBrand"));
						mobileDTO.setMobModel(rs.getString("mobModel"));
						mobileDTO.setMobPrice(rs.getDouble("mobPrice"));
						mobileDTO.setMobStock(rs.getInt("mobStock"));

						System.out.println("\nDatabase Entry " + result);
						displayMobile(mobileDTO);

					}
				}
				ps.close();
			}
			con.close();
		}

		catch (SQLException e) {
			System.out.println(e.toString());
		}

		return result;
	}

	public void displayAll() {

		try (Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");) {
			try (PreparedStatement ps = con.prepareStatement("SELECT * FROM mobile_details");) {
				try (ResultSet rs = ps.executeQuery()) {
					
					result = 0;
					
					while (rs.next()) {

						result++;

						mobileDTO.setMobSerialNum(rs.getString("mobSerialNum"));
						mobileDTO.setMobBrand(rs.getString("mobBrand"));
						mobileDTO.setMobModel(rs.getString("mobModel"));
						mobileDTO.setMobPrice(rs.getDouble("mobPrice"));
						mobileDTO.setMobStock(rs.getInt("mobStock"));

						System.out.println("\nDatabase Entry " + result);
						displayMobile(mobileDTO);

					}
				}
				ps.close();
			}
			con.close();
		}

		catch (SQLException e) {
			System.out.println(e.toString());
		}

	}

	public void displayMobile(MobileDTO mobileDTO) {

		if (mobileDTO != null) {
			System.out.println("\nSerial Number : " + mobileDTO.getMobSerialNum());
			System.out.println("Brand Name : " + mobileDTO.getMobBrand());
			System.out.println("Model Name : " + mobileDTO.getMobModel());
			System.out.println("Price : " + mobileDTO.getMobPrice());
			System.out.println("Current Stock : " + mobileDTO.getMobStock());
		}
	}
	
	public int deleteByModel(String mobModel) {
		
		try (Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");) {
			try (PreparedStatement ps = con.prepareStatement("DELETE FROM mobile_details WHERE mobModel = ?");) {
				ps.setString(1, mobModel);
				
				rows = ps.executeUpdate();
				
				ps.close();
			}
			con.close();
		}

		catch (SQLException e) {
			System.out.println(e.toString());
		}

		return rows;
	}
	
	public int deleteAll() {
		
		try (Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");) {
			try (PreparedStatement ps = con.prepareStatement("TRUNCATE TABLE mobile_details");) {
				
				rows = ps.executeUpdate();
				
				ps.close();
			}
			con.close();
		}

		catch (SQLException e) {
			System.out.println(e.toString());
		}

		return rows;
	}
}

//try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wolken?user=root&password=NewPassword@WolkenOkta01");)
//{
//	try (PreparedStatement ps = con.prepareStatement("INSERT INTO mobile_details VALUES (?,?,?,?");)
//	{
//		
//	}
//}
//
//catch(SQLException e) {
//	System.out.println(e.toString());
//}