package com.wolken.wolkenapp;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.wolken.wolkenapp.dto.MobileDTO;
import com.wolken.wolkenapp.service.MobileService;
import com.wolken.wolkenapp.service.MobileServiceImpl;

public class MobileTester {

	MobileDTO mobileDTO = new MobileDTO();
	MobileService mobileService = new MobileServiceImpl();

	public void getDetails(int n) {
		Scanner sc = new Scanner(System.in);
		
		try {

			for (int i = 0; i < n; i++) {

				System.out.println("Enter Mobile Serial Number : ");
				mobileDTO.setMobSerialNum(sc.next());

				System.out.println("Enter Mobile Brand Name : ");
				mobileDTO.setMobBrand(sc.next());

				System.out.println("Enter Mobile Model Name : ");
				mobileDTO.setMobModel(sc.next());

				System.out.println("Enter Mobile Price : ");
				mobileDTO.setMobPrice(sc.nextDouble());

				System.out.println("Enter Mobile Stock : ");
				mobileDTO.setMobStock(sc.nextInt());

				mobileService.validateAndAdd(mobileDTO);

//				sc.close();
			}
		}

		catch (InputMismatchException e) {
			System.out.println("Entered data differs from expected data");
		}
	}

	public static void main(String[] args) {

		MobileTester mobileTester = new MobileTester();
		boolean run = true;

		while (run) {
			
			Scanner sc = new Scanner(System.in);
			
			try {
				
				System.out.println(
						"\nList of options\n1 - Add a new Mobile\n2 - Update Price by Serial Number\n3 - Update Stock by Model Name\n4 - Display database entries by Brand\n5 - Display database entries by Serial Number\n6 - Display all Mobile details in database\n7 - Delete database entries by Model\n8 - Delete all\n9 - Exit\nEnter your choice :");
				int ch = sc.nextInt();
				switch (ch) {

				case 1:
					try {
						System.out.println("\nEnter number of entries :");
						int n = sc.nextInt();
						mobileTester.getDetails(n);
						break;
					} catch (InputMismatchException e) {
						System.out.println("Entered data differs from expected data");
//						run = false;
						break;
						
					}

				case 2:
					try {
						System.out.println("Enter Serial Number :");
						String mobSerialNum = sc.next();
						System.out.println("Enter New Price to be updated : ");
						double mobPrice = sc.nextDouble();
						mobileTester.mobileService.validateSerialAndUpdatePrice(mobSerialNum, mobPrice);
						break;
					} catch (InputMismatchException e) {
						System.out.println("Entered data differs from expected data");
					}

				case 3:
					try {
						System.out.println("Enter Model Name :");
						String mobModel = sc.next();
						System.out.println("Enter New Stock to be updated : ");
						int mobStock = sc.nextInt();
						mobileTester.mobileService.validateModelAndUpdateStock(mobModel, mobStock);
						break;
					} catch (InputMismatchException e) {
						System.out.println("Entered data differs from expected data");
					}

				case 4:
					try {
						System.out.println("Enter Brand Name :");
						String mobBrand = sc.next();
						mobileTester.mobileService.validateBrandAndDisplay(mobBrand);
						break;
					} catch (InputMismatchException e) {
						System.out.println("Entered data differs from expected data");
					}

				case 5:
					try {
						System.out.println("Enter Serial Number :");
						String mobSerialNum = sc.next();
						mobileTester.mobileService.validateSerialNumAndDisplay(mobSerialNum);
						break;
					} catch (InputMismatchException e) {
						System.out.println("Entered data differs from expected data");
					}

				case 6:
					try {
						mobileTester.mobileService.displayAll();
						break;

					} catch (InputMismatchException e) {
						System.out.println("Entered data differs from expected data");
					}

				case 7:
					try {
						System.out.println("Enter Model Name :");
						String mobModel = sc.next();
						mobileTester.mobileService.validateModelAndDelete(mobModel);
						break;
					} catch (InputMismatchException e) {
						System.out.println("Entered data differs from expected data");
					}

				case 8:
					mobileTester.mobileService.deleteAll();
					break;

				case 9:
					run = false;
					break;

				default:
					System.out.println("Enter a valid choice !!");

				}
			} catch (InputMismatchException e) {
				System.out.println("Entered data differs from expected data");
			}
		}
	}
}
