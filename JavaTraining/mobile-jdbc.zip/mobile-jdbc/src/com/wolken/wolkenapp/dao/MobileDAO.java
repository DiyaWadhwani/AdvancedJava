package com.wolken.wolkenapp.dao;

import com.wolken.wolkenapp.dto.MobileDTO;

public interface MobileDAO {
	
	public int add(MobileDTO mobileDTO);
	public int updatePriceBySerialNum(String mobSerialNum, double mobPrice);
	public int updateStockByModel(String mobModel, int mobStock);
	public int displayByBrand(String mobBrand);
	public int displayBySerialNum (String mobSerialNum);
	public void displayAll();
	public void displayMobile(MobileDTO mobileDTO);
	public int deleteByModel(String mobModel);
	public int deleteAll();

}
