package com.wolken.wolkenapp.custom;

public class NameException extends Exception {
	
	@Override
	public String toString() {
		return "Invalid Entry - Name must be more than 3 characters";
	}
}
