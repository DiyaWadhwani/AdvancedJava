package com.wolken.wolkenapp.custom;

public class BrandException extends Exception {
	
	@Override
	public String toString() {
		
		return "Invalid entry - Brand Name must be more than 3 characters";
	}

}
