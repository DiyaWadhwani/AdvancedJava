package com.wolken.wolkenapp.custom;

public class SerialNumException extends Exception {
	
	@Override
	public String toString() {
		return "Invalid entry - Serial Number must be of 10-20 characters";
	}
}
