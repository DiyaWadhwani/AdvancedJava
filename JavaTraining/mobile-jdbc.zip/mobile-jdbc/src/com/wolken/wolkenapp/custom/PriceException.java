package com.wolken.wolkenapp.custom;

public class PriceException extends Exception {
	
	@Override
	public String toString() {
		
		return "Invalid entry - Price must be between Rs.5000 and Rs.500000 for Mobile to be added into the database";
	}
}
