package com.wolken.wolkenapp.custom;

public class PhoneNumException extends Exception {
	
	@Override
	public String toString() {
		return "Invalid Entry - Phone number must be 10 digits long";
	}
}
