package com.wolken.wolkenapp.service;

import com.wolken.wolkenapp.dto.MobileDTO;

public interface MobileService {
	
	public void validateAndAdd(MobileDTO mobileDTO);
	public void validateSerialAndUpdatePrice(String mobSerialNum, double mobPrice);
	public void validateModelAndUpdateStock(String mobModel, int mobStock);
	public void validateBrandAndDisplay(String mobBrand);
	public void validateSerialNumAndDisplay(String mobSerialNum);
	public void displayAll();
	public void validateModelAndDelete(String mobModel);
	public void deleteAll();

}
