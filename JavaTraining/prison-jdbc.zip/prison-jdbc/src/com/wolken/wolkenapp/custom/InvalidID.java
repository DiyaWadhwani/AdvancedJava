package com.wolken.wolkenapp.custom;

public class InvalidID extends Exception {
	
	public String toString() {
		return "Invalid entry - Prison ID is not valid !";
	}

}
