package com.wolken.wolkenapp.custom;

public class EmailException extends Exception {
	
	@Override
	public String toString() {
		return "Invalid Entry - Email ID not in correct format";
	}
}
