package com.wolken.wolkenapp;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.wolken.wolkenapp.dao.PrisonDAO;
import com.wolken.wolkenapp.dao.PrisonDAOImpl;
import com.wolken.wolkenapp.dto.PrisonDTO;
import com.wolken.wolkenapp.service.PrisonService;
import com.wolken.wolkenapp.service.PrisonServiceImpl;

public class PrisonTester {

	PrisonDTO prisonDTO = new PrisonDTO();
	PrisonDAO prisonDAO = new PrisonDAOImpl();
	boolean enter = false;

	Scanner sc = new Scanner(System.in);

	public void enterDeets(int n) throws SQLException {

		for (int i = 0; i < n; i++) {

			try {

				System.out.println("\nEnter Prison ID : ");
				prisonDTO.setPrisonID(sc.nextInt());

				System.out.println("Enter Prison Name : ");
				prisonDTO.setPrisonName(sc.next());

				System.out.println("Enter No. of Inmates : ");
				prisonDTO.setPrisonInmates(sc.nextInt());

				System.out.println("Enter No. of Staff : ");
				prisonDTO.setPrisonStaff(sc.nextInt());

				PrisonService prisonService = new PrisonServiceImpl();
				prisonService.validateAndInsert(prisonDTO);

			} catch (InputMismatchException e) {
				System.out.println(e.toString());
			}
		}

	}

	public static void main(String[] args) throws SQLException {
		
		PrisonTester prisonTester = new PrisonTester();
		PrisonService prisonService = new PrisonServiceImpl();

		while (true) {

			System.out.println(
					"\nList of options:\n1 - Add a new row\n2 - Update by ID\n3 - Display all\n4 - Delete by ID\n5 - Delete all\n6 - Exit\nEnter your choice");
			int ch = prisonTester.sc.nextInt();

			switch (ch) {

			case 1:
				try {
					System.out.println("Enter no. of entries :");
					int i = prisonTester.sc.nextInt();
					prisonTester.enterDeets(i);
					break;

				} catch (InputMismatchException e) {
					System.out.println(e.toString());
				}

			case 2:
				System.out.println("Enter Prison ID of item to be updated");
				int id = prisonTester.sc.nextInt();
				System.out.println("Enter New Prison Name :");
				String name = prisonTester.sc.next();
				prisonService.validateAndUpdate(name, id);
				break;

			case 3:
				int res = prisonTester.prisonDAO.displayAll();
				if (res == 0) {
					System.out.println("Database is empty\nEnter 1 to Add a new row in the database");
				}
				break;

			case 4:
				System.out.println("Enter ID of entry to be deleted from database");
				id = prisonTester.sc.nextInt();
				prisonService.validateAndDelete(id);
				break;

			case 5:
				int done = prisonTester.prisonDAO.deleteAll();
				if (done == 0) {
					System.out.println("No entries exist in the database\nDatabase is empty !!");
				}
				break;

			case 6:
				System.exit(0);
				break;

			default:
				System.out.println("This choice does not exist !!\n Please enter a choice between 1-6");
			}

		}

	}

}
