package com.wolken.wolkenapp.service;

import java.sql.SQLException;

import com.wolken.wolkenapp.dto.PrisonDTO;

public interface PrisonService {

	public void validateAndInsert(PrisonDTO prisonDTO) throws SQLException;
	public void validateAndUpdate(String prisonName, int prisonID) throws SQLException;
	public void validateAndDelete(int prisonID) throws SQLException;
	

}
