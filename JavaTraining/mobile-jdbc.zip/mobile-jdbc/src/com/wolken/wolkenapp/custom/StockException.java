package com.wolken.wolkenapp.custom;

public class StockException extends Exception {
	
	@Override
	public String toString() {
		
		return "Restock required !! Stock is less than 50"; 
	}

}
