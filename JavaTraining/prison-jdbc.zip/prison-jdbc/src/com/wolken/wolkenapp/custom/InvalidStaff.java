package com.wolken.wolkenapp.custom;

public class InvalidStaff extends Exception {
	
	public String toString() {
		return "Invalid entry - Not enough Staff in the prison for row to be added into database !";
	}

}
