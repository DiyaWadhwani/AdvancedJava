package com.wolken.wolkenapp.service;

import com.wolken.wolkenapp.custom.BrandException;
import com.wolken.wolkenapp.custom.ModelException;
import com.wolken.wolkenapp.custom.PriceException;
import com.wolken.wolkenapp.custom.SerialNumException;
import com.wolken.wolkenapp.custom.StockException;
import com.wolken.wolkenapp.dao.MobileDAO;
import com.wolken.wolkenapp.dao.MobileDAOImpl;
import com.wolken.wolkenapp.dto.MobileDTO;

public class MobileServiceImpl implements MobileService {

	MobileDAO mobileDAO = new MobileDAOImpl();
	int rows = 0;

	public void validateAndAdd(MobileDTO mobileDTO) {

		try {
			if (mobileDTO.getMobSerialNum().length() < 10 || mobileDTO.getMobSerialNum().length() > 20) {
				throw new SerialNumException();
			}
		} catch (SerialNumException e) {
			System.out.print(e.toString());
			return;
		}

		try {
			if (mobileDTO.getMobBrand().length() < 3) {
				throw new BrandException();
			}
		} catch (BrandException e) {
			System.out.println(e.toString());
			return;
		}

		try {
			if (mobileDTO.getMobModel().length() < 2) {
				throw new ModelException();
			}
		} catch (ModelException e) {
			System.out.println(e.toString());
			return;
		}

		try {
			if (mobileDTO.getMobPrice() < 5000.0 || mobileDTO.getMobPrice() > 500000) {
				throw new PriceException();
			}
		} catch (PriceException e) {
			System.out.println(e.toString());
			return;
		}

		try {
			if (mobileDTO.getMobStock() < 50) {
				throw new StockException();
			}
		} catch (StockException e) {
			System.out.println(e.toString());
			return;
		}

		rows = mobileDAO.add(mobileDTO);

		if (rows < 0) {
			System.out.println("\nMobile not added into the database");
		} else {
			System.out.println("\nMobile added into the database successfully !!\n" + rows + " row(s) affected\n");
			mobileDAO.displayMobile(mobileDTO);
		}

	}

	public void validateSerialAndUpdatePrice(String mobSerialNum, double mobPrice) {

		try {
			if (mobSerialNum.length() < 10 || mobSerialNum.length() > 20) {
				throw new SerialNumException();
			}
		} catch (SerialNumException e) {
			System.out.print(e.toString());
			return;
		}

		try {
			if (mobPrice < 5000.0 || mobPrice > 500000) {
				throw new PriceException();
			}
		} catch (PriceException e) {
			System.out.println(e.toString());
			return;
		}

		rows = mobileDAO.updatePriceBySerialNum(mobSerialNum, mobPrice);

		if (rows < 0) {
			System.out.println("Update failed - Some error has occured");
		} else {
			System.out.println("Mobile Price updated successfully !! " + rows
					+ " row(s)affected\nEnter 6 to view changes in database");
		}

	}

	public void validateModelAndUpdateStock(String mobModel, int mobStock) {

		try {
			if (mobModel.length() < 2) {
				throw new ModelException();
			}
		} catch (ModelException e) {
			System.out.println(e.toString());
			return;
		}

		try {
			if (mobStock < 50) {
				throw new StockException();
			}
		} catch (StockException e) {
			System.out.println(e.toString());
			return;
		}

		rows = mobileDAO.updateStockByModel(mobModel, mobStock);

		if (rows < 0) {
			System.out.println("Update failed - Some error has occured");
		} else {
			System.out.println("Mobile Stock updated successfully !! " + rows
					+ " row(s)affected\nEnter 6 to view changes in database");
		}

	}

	public void validateBrandAndDisplay(String mobBrand) {

		try {
			if (mobBrand.length() < 3) {
				throw new BrandException();
			}
		} catch (BrandException e) {
			System.out.println(e.toString());
			return;
		}

		rows = mobileDAO.displayByBrand(mobBrand);

		if (rows <= 0) {
			System.out.println(
					"No mobile with Brand " + mobBrand + " exists yet\nEnter 1 to add a new mobile to the database");
		}
	}

	public void validateSerialNumAndDisplay(String mobSerialNum) {

		try {
			if (mobSerialNum.length() < 10 || mobSerialNum.length() > 20) {
				throw new SerialNumException();
			}
		} catch (SerialNumException e) {
			System.out.print(e.toString());
			return;
		}

		rows = mobileDAO.displayBySerialNum(mobSerialNum);

		if (rows < 0) {
			System.out.println("No mobile with Serial Number " + mobSerialNum
					+ " exist yet\nEnter 1 to add a new mobile to the database");
		}

	}

	public void displayAll() {
		
		mobileDAO.displayAll();
	}
	
	public void validateModelAndDelete(String mobModel) {
		
		try {
			if (mobModel.length() < 2) {
				throw new ModelException();
			}
		} catch (ModelException e) {
			System.out.println(e.toString());
			return;
		}
		
		rows = mobileDAO.deleteByModel(mobModel);

		if (rows < 0) {
			System.out.println("Update failed - Some error has occured");
		} else {
			System.out.println("Database entry of Mobile with Model "+mobModel+" has been deleted !!\n" + rows
					+ " row(s)affected\nSelect 6 to view changes in database");
		}

		
	}

	public void deleteAll() {
		rows = mobileDAO.deleteAll();
		
		if(rows < 0) {
			System.out.println("No entries exist in database\nEnter 1 to add new item");
		}
		else {
			System.out.println("Database is now empty\n");
		}
	}
}


