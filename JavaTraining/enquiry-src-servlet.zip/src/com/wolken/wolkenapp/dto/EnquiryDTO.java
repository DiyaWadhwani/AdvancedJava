package com.wolken.wolkenapp.dto;

public class EnquiryDTO {

	private String firstName;
	private String lastName;
	private String gender;
	private String dob;
	private long phnum;
	private String email;
	private String qual;

	// First Name
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	// Last Name
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	// Gender
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	// Date of Birth
	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	// Phone number
	public long getPhnum() {
		return phnum;
	}

	public void setPhnum(long phnum) {
		this.phnum = phnum;
	}

	// Email
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	// Qualification
	public String getQual() {
		return qual;
	}

	public void setQual(String qual) {
		this.qual = qual;
	}

}
