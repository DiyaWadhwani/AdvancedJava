package com.wolken.wolkenapp.dao;

import java.sql.SQLException;

import com.wolken.wolkenapp.dto.PrisonDTO;

public interface PrisonDAO {
	
	public int insert(PrisonDTO prisonDTO) throws SQLException;
	public int updateNameByID(String prisonName, int prisonID) throws SQLException;
	public int displayAll() throws SQLException;
	public int deleteEntryByID(int prisonID) throws SQLException;
	public int deleteAll() throws SQLException;
	public void displayPrisoners(PrisonDTO prisonDTO);
	
	
		
}
