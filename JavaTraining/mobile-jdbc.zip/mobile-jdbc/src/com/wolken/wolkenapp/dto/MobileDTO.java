package com.wolken.wolkenapp.dto;

public class MobileDTO {
	
	private String mobSerialNum;
	private String mobBrand;
	private String mobModel;
	private double mobPrice;
	private int mobStock;
	
	//mobSerialNum
	public String getMobSerialNum() {
		return mobSerialNum;
	}
	public void setMobSerialNum(String i) {
		this.mobSerialNum = i;
	}
	
	//mobBrand
	public String getMobBrand() {
		return mobBrand;
	}
	public void setMobBrand(String mobBrand) {
		this.mobBrand = mobBrand;
	}
	
	//mobModel
	public String getMobModel() {
		return mobModel;
	}
	public void setMobModel(String mobModel) {
		this.mobModel = mobModel;
	}
	
//	mobPrice
	public double getMobPrice() {
		return mobPrice;
	}
	public void setMobPrice(double mobPrice) {
		this.mobPrice = mobPrice;
	}
	
//	mobStock
	public int getMobStock() {
		return mobStock;
	}
	public void setMobStock(int mobStock) {
		this.mobStock = mobStock;
	}
	
	
	
	

}
