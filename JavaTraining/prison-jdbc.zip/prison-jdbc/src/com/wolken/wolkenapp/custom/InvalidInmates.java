package com.wolken.wolkenapp.custom;

public class InvalidInmates extends Exception {
	
	public String toString() {
		return "Invalid entry - Not enough Prisoners in the prison for row to be added into database !";
	}
}
