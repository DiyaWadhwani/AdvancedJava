package com.wolken.wolkenapp.dto;

public class PrisonDTO {
	
	private int prisonID;
	private String prisonName;
	private int prisonInmates;
	private int prisonStaff;

	
	public int getPrisonID() {
		return prisonID;
	}
	public void setPrisonID(int prisonID) {
		this.prisonID = prisonID;
	}
	public String getPrisonName() {
		return prisonName;
	}
	public void setPrisonName(String prisonName) {
		this.prisonName = prisonName;
	}
	public int getPrisonInmates() {
		return prisonInmates;
	}
	public void setPrisonInmates(int prisonInmates) {
		this.prisonInmates = prisonInmates;
	}
	public int getPrisonStaff() {
		return prisonStaff;
	}
	public void setPrisonStaff(int prisonStaff) {
		this.prisonStaff = prisonStaff;
	}
	
	

}
